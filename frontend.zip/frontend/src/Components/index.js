import Calculadora from './Calculadora';

export default Calculadora;