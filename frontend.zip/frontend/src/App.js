import React, { Component } from 'react';
import './index.css';
import axios from "axios";
import { useState } from "react"


export default function App() {
    const [calc, setCalc] = useState("");
    const [result, setResult] = useState("");
	
    
    
    const ops = ['/', '*', '+', '-', '.'];
    
    const updateCalc = value => {
        if (
            (ops.includes(value) && calc === '') ||
            (ops.includes(value) && ops.includes(calc.slice(-1))
            )
		){
            return;
        }
		if ( ops.includes(value) && calc.includes('/') ||
			(ops.includes(value) && calc.includes('*')) ||
			(ops.includes(value) && calc.includes('+')) ||
			(ops.includes(value) && calc.includes('-'))
		){
            return;
        }
    
        setCalc(calc + value);
        console.log(typeof(calc))
        if (!ops.includes(value)){
            setResult(eval(calc+value).toString());
        }
    }
    
    const calcular = () => {
        setCalc(eval(calc).toString())
    }
    
    const deleteLast = () => {
        if (calc === ''){
            return;
        }
        const value = '';
        setCalc(value);
    }
    

    const crearNumeros = () =>{
        const nums = []
            
        for (let i = 1; i < 10; i++){
            nums.push(
                <button onClick={() => updateCalc(i.toString())} key={i}>{i}</button>
            )
        }
    
        return nums
        
    }
    
    const createPost = () => {
		const envioDatos = {
			manejo: calc
		}
		const prueba = JSON.stringify(envioDatos)=
		axios.post("http://localhost:8081/calcular", prueba , {headers: {'Content-Type': 'multipart/form-data'}})
		.then(response => {
            console.log(response);
            var Respuesta = JSON.parse(response.data);
            setResult(Respuesta.Resultado);
			setCalc(Respuesta.Resultado);
		}).catch(error => {
			console.log("Error?????");
			console.log(error);
            setResult("Ocurrio un Error");
			setCalc("Ocurrio un Error");
		});
  	}

    return (
        <div className="App">
            <div className="calculadora">
                <div className="display">
                    {result ? <span>({result})</span>: '' }&nbsp;
                    {calc || "0"}
                </div>
    
                <div className="operadores">
                    <button onClick={() => updateCalc('/')}>/</button>
                    <button onClick={() => updateCalc('*')}>*</button>
                    <button onClick={() => updateCalc('+')}>+</button>
                    <button onClick={() => updateCalc('-')}>-</button>
    
                    <button onClick={deleteLast}>DEL</button>
                </div>
    
    
                <div className="numeros">
                    { crearNumeros() }
                    <button onClick={() => updateCalc('0')}>0</button>
                    <button onClick={() => updateCalc('.')}>.</button>
                    <button onClick={createPost}>=</button>
                </div>
    
            </div>
        </div>
    );
}